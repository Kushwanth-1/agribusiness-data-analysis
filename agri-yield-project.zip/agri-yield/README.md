# Agri Predictive Analytics Model

Forecast district-level crop yield at **week 20** of the agricultural year and explain the drivers, for a fictional Nagpur agritech start-up (Yuva Intern project).

> **Data note:** the project brief ships no dataset, so `src/generate_data.py` builds a seeded synthetic one (~349,959 rows) containing the problems the brief lists. Results show the method, not real Vidarbha yields.

## Results
- Final model (gradient boosting) beats the 3-year-average baseline by **42.0%** on validation and **31.0%** on test (test MAE 1.19 q/ha per district-crop).
- Not met: test error is 40% above validation, largely traced to unusually wet seasons (see notebook section 9b).
- Main drivers: monsoon rainfall and price signals.

## Repository layout
```
src/generate_data.py          synthetic raw data (seeded)
src/build_notebook.py         runs notebooks/analysis.py and writes the executed notebook
src/build_deck.js, build_report.js, build_docs.py   build the deck, Word report and docs
notebooks/analysis.py         the full analysis (cell-marked script)
notebooks/agri_yield_analysis.ipynb   executed notebook with outputs and figures
models/yield_model.joblib     trained model + feature list
reports/model_card.md, metrics.json, test_predictions.csv, figures/
data/raw/agri_raw.csv.gz      generated raw data
data/processed/model_table.csv.gz   modelling table
deliverables/                 Word report, 8-slide deck, project description
```

## Reproduce
```bash
pip install -r requirements.txt
python src/generate_data.py      # writes data/raw/agri_raw.csv.gz
python src/build_notebook.py     # runs the analysis, writes notebooks/agri_yield_analysis.ipynb
```
`shap` is optional: the notebook uses it if installed, otherwise a permutation-sampling Shapley estimator.

## Method in one paragraph
Clean (duplicates, labels, per-kg prices, yield units, rainfall imputation from neighbouring blocks) -> leakage audit (post-harvest columns, season totals, post-harvest prices excluded) -> time-aware split (train 2006-2019, validation 2020-2022, test 2023-2025) -> 50 features with past-only target encoding -> compare baseline, ridge, random forest, gradient boosting with expanding-window CV -> tune the best -> Shapley and partial dependence -> procurement actions -> fairness and stability checks -> one wrong prediction explained.
