"""
Synthetic raw data generator for the Agri Predictive Analytics Model project.

The brief describes a FICTIONAL Nagpur agritech start-up and ~350,000 rows of crop yield,
rainfall, soil-test and mandi-price records across 6 districts, but supplies no file.
This script builds a realistic, fully seeded stand-in that deliberately contains the
data problems the brief lists:

  * mandi prices entered per quintal AND per kg in the same column
  * missing rainfall readings during the monsoon (more likely in heavy-rain weeks)
  * yield values recorded in the wrong units (kg/acre, t/ha, and mislabelled rows)
  * leakage-prone columns that only exist after harvest
  * high-cardinality categoricals (block, mandi, seed variety)
  * duplicated rows, messy category labels, sentinel values, missing soil tests

Granularity: one row = block x crop x week of the agricultural year (June -> May).
Run:  python src/generate_data.py      (writes data/raw/agri_raw.csv.gz)
"""
import numpy as np
import pandas as pd
from pathlib import Path

SEED = 2026
rng = np.random.default_rng(SEED)

YEARS = np.arange(2003, 2026)           # agricultural year starts 1 June of this year
NY, NW, NB = len(YEARS), 52, 8
DISTRICTS = ["Nagpur", "Wardha", "Amravati", "Yavatmal", "Chandrapur", "Bhandara"]
CODE = dict(zip(DISTRICTS, ["NGP", "WRD", "AMT", "YVT", "CHD", "BHD"]))
CROPS = ["Soybean", "Cotton", "Tur", "Rice", "Wheat", "Gram"]

DIST = {  # monsoon mean (mm, wk1-17), irrigation share, base effect
    "Nagpur": (1050, 0.30, 0.05), "Wardha": (950, 0.20, 0.00), "Amravati": (880, 0.22, 0.02),
    "Yavatmal": (820, 0.12, -0.08), "Chandrapur": (1250, 0.35, 0.03), "Bhandara": (1300, 0.55, 0.06),
}
CROP = {  # base q/ha, optimum monsoon mm, rain curvature, dry-spell penalty, season, harvest wk, price/q 2025, tech growth
    "Soybean": (12.5, 850, 0.90, 0.050, "kharif", 18, 4600, 0.006),
    "Cotton":  (9.0, 900, 0.70, 0.035, "kharif", 28, 7000, 0.007),
    "Tur":     (8.5, 750, 0.80, 0.030, "kharif", 32, 7500, 0.005),
    "Rice":    (24.0, 1150, 0.50, 0.040, "kharif", 20, 2300, 0.008),
    "Wheat":   (27.0, 950, 0.25, 0.010, "rabi", 40, 2400, 0.009),
    "Gram":    (11.0, 900, 0.25, 0.010, "rabi", 38, 5400, 0.006),
}
CUTOFF_WEEK = 20   # forecast is issued at end of week 20 (~mid Oct): used later in the notebook

# ----------------------------------------------------------------------------- weather
common = np.zeros(NY)
for yr, v in {2009: -.25, 2014: -.20, 2015: -.25, 2018: -.15, 2019: .20, 2022: .15}.items():
    common[YEARS == yr] = v
dy_factor = np.exp(rng.normal(0, 0.16, (6, NY)) + common)          # district-year monsoon intensity
w = np.arange(1, NW + 1)
prof = np.where(w <= 17, np.exp(-((w - 9) / 4.5) ** 2), 0.0)
prof = prof / prof.sum()

rain = np.zeros((6, NB, NY, NW), dtype=np.float32)
tmax = np.zeros((6, NB, NY, NW), dtype=np.float32)
for di, d in enumerate(DISTRICTS):
    mm = DIST[d][0]
    for yi in range(NY):
        mean_w = np.where(w <= 17, mm * dy_factor[di, yi] * prof, 0.0)
        dist_w = np.where(w <= 17, rng.gamma(1.6, 1, NW) * mean_w / 1.6,
                          (rng.random(NW) < 0.12) * rng.gamma(1.0, 18, NW))
        anom = rng.normal(0, 0.8) + 0.03 * yi - 1.5 * (dy_factor[di, yi] < 0.85)
        for b in range(NB):
            rain[di, b, yi] = dist_w * np.exp(rng.normal(0, 0.25, NW))
            base = 35 + 7 * np.cos(2 * np.pi * (w - 1) / 52) - 5 * np.exp(-((w - 9) / 4.5) ** 2)
            tmax[di, b, yi] = base + anom + rng.normal(0, 1.2, NW)

def longest_run(x):
    best = cur = 0
    for v in x:
        cur = cur + 1 if v else 0
        best = max(best, cur)
    return best

# ----------------------------------------------------------------------------- soil tests (per block-year)
block_soil = {k: rng.normal(0, 1, (6, NB)) for k in ["oc", "n", "p", "k", "ph"]}
soil = {}
for key, mu, sd in [("oc", 0.55, 0.12), ("n", 210, 35), ("p", 16, 4), ("k", 280, 50), ("ph", 7.2, 0.45)]:
    drift = rng.normal(0, 0.15, (6, NB, NY)).cumsum(axis=2) * 0.25
    soil[key] = mu + sd * (block_soil[key][:, :, None] * 0.9 + drift + rng.normal(0, 0.25, (6, NB, NY)))

# ----------------------------------------------------------------------------- national price index (per crop-year, AR1)
price_nat = {}
for c in CROPS:
    p25 = CROP[c][6]
    shock = np.zeros(NY)
    for i in range(1, NY):
        shock[i] = 0.4 * shock[i - 1] + rng.normal(0, 0.08)
    trend = p25 * (1.055 ** (YEARS - 2025))
    price_nat[c] = trend * np.exp(shock)

# ----------------------------------------------------------------------------- yield (q/ha) data-generating process
block_eff = rng.normal(0, 0.07, (6, NB))
cd_eff = rng.normal(0, 0.08, (6, len(CROPS)))
rice_adj = {"Bhandara": 0.25, "Chandrapur": 0.15, "Yavatmal": -0.20}
varieties = {c: [f"{c[:3].upper()}-{i:02d}" for i in range(1, 41)] for c in CROPS}
var_eff = {c: rng.normal(0, 0.04, 40) for c in CROPS}

records, season_rows = [], []
for di, d in enumerate(DISTRICTS):
    mm, irr, dbase = DIST[d]
    for ci, c in enumerate(CROPS):
        base, opt, k, dry_pen, season, hw, p25, g = CROP[c]
        for b in range(NB):
            ar = 0.0
            for yi, yr in enumerate(YEARS):
                r = rain[di, b, yi]
                R = r[:17].sum()
                k_eff = k * (1 - 0.6 * irr)
                rain_eff = -k_eff * (R / opt - 1) ** 2
                run = longest_run(r[4:14] < 12)
                dry_eff = -dry_pen * (1 - 0.5 * irr) * run
                heat_eff = (-0.03 * (tmax[di, b, yi, 7:14] > 35).sum()) if season == "kharif" else 0.0
                heat_post = (-0.05 * (tmax[di, b, yi, 29:38] > 33).sum()) if season == "rabi" else 0.0
                late_rain = r[17:24].sum() if season == "kharif" else 0.0
                late_eff = -0.0006 * max(0, late_rain - 60)
                z = lambda a, m, s: (a - m) / s
                soil_eff = (0.10 * z(soil["oc"][di, b, yi], 0.55, 0.12) + 0.06 * z(soil["n"][di, b, yi], 210, 35)
                            + 0.04 * z(soil["p"][di, b, yi], 16, 4) - 0.05 * abs(soil["ph"][di, b, yi] - 7.0) / 0.45)
                pprev = np.log(price_nat[c][yi - 1] / (p25 * 1.055 ** (YEARS[yi - 1] - 2025))) if yi > 0 else 0.0
                price_eff = 0.15 * pprev
                irr_eff = 0.30 * irr if season == "rabi" else 0.10 * irr
                shock = 0.0
                if d == "Yavatmal" and c == "Cotton" and yr in (2015, 2017): shock -= 0.18   # pink bollworm
                if d == "Amravati" and season == "kharif" and yr == 2020: shock -= 0.12      # floods
                drift = 0.10 if (d == "Chandrapur" and yr >= 2021 and c in ("Wheat", "Gram", "Rice")) else 0.0  # canal irrigation
                ar = 0.5 * ar + rng.normal(0, 0.06)
                vi = rng.integers(0, 40)
                logy = (np.log(base) + g * (yr - 2003) + dbase + block_eff[di, b] + cd_eff[di, ci]
                        + (rice_adj.get(d, 0) if c == "Rice" else 0) + rain_eff + dry_eff + heat_eff + heat_post
                        + late_eff + soil_eff + price_eff + irr_eff + shock + drift + ar + var_eff[c][vi]
                        + rng.normal(0, 0.05))
                y = float(np.exp(logy))
                records.append(dict(di=di, b=b, ci=ci, yi=yi, y_true=y, variety=varieties[c][vi]))

seasons = pd.DataFrame(records)
# district-level yield deviation (for supply response in post-harvest prices)
seasons["dev"] = np.log(seasons.y_true) - seasons.groupby(["di", "b", "ci"]).y_true.transform(lambda s: np.log(s).mean())
area = np.exp(rng.normal(np.log(2800), 0.35, len(seasons)))     # sown hectares per block-crop-season (known at sowing)
seasons["area_ha"] = area.round(0)

# ----------------------------------------------------------------------------- expand to weekly rows
mandi_of = {(di, b): f"{CODE[DISTRICTS[di]]}-Mandi-{b + 1}" for di in range(6) for b in range(NB)}
mandi_prem = {k: rng.normal(0, 0.03) for k in mandi_of}
kg_mandi_year = set()   # (di,b,yi) whose clerks entered per-kg prices for the whole year (data-entry quirk)
for di in range(6):
    for b in range(NB):
        for yi in range(NY):
            if YEARS[yi] >= 2012 and rng.random() < 0.09:
                kg_mandi_year.add((di, b, yi))

frames = []
for s in seasons.itertuples(index=False):
    c = CROPS[s.ci]
    base, opt, k, dry_pen, season, hw, p25, g = CROP[c]
    seas = 1 - 0.07 * np.cos(2 * np.pi * (w - hw) / 52)
    resp = np.where(w > hw, -0.35 * s.dev, -0.08 * s.dev)           # post-harvest prices carry the supply shock (LEAKAGE)
    price = (price_nat[c][s.yi] * seas * np.exp(resp + mandi_prem[(s.di, s.b)] + rng.normal(0, 0.015, NW)))
    if (s.di, s.b, s.yi) in kg_mandi_year:
        price = price / 100.0
    frames.append(pd.DataFrame({
        "di": s.di, "b": s.b, "ci": s.ci, "yi": s.yi, "week_no": w,
        "rainfall_mm": rain[s.di, s.b, s.yi], "temp_max_c": tmax[s.di, s.b, s.yi],
        "mandi_price": price, "y_true": s.y_true, "seed_variety": s.variety, "area_ha": s.area_ha,
    }))
df = pd.concat(frames, ignore_index=True)
del frames

# ----------------------------------------------------------------------------- assemble raw columns
df["ag_year"] = YEARS[df.yi.values]
df["week_start_date"] = (pd.to_datetime(df.ag_year.astype(str) + "-06-01") + pd.to_timedelta((df.week_no - 1) * 7, unit="D")).dt.strftime("%Y-%m-%d")
df["district"] = np.array(DISTRICTS)[df.di.values]
df["block"] = [f"{CODE[DISTRICTS[a]]}-Block-{b + 1}" for a, b in zip(df.di.values, df.b.values)]
df["mandi_name"] = [mandi_of[(a, b)] for a, b in zip(df.di.values, df.b.values)]
df["crop"] = np.array(CROPS)[df.ci.values]
for key, col in [("oc", "soil_oc_pct"), ("n", "soil_n_kg_ha"), ("p", "soil_p_kg_ha"), ("k", "soil_k_kg_ha"), ("ph", "soil_ph")]:
    df[col] = soil[key][df.di.values, df.b.values, df.yi.values]

# yield units (season-level quirks)
season_key = df.groupby(["di", "b", "ci", "yi"]).ngroup()
ns = season_key.max() + 1
u = rng.random(ns)
unit_lab = np.where(u < 0.07, "kg/acre", np.where(u < 0.11, "t/ha", "q/ha"))
mislabel = (unit_lab == "q/ha") & (rng.random(ns) < 0.012)             # value in kg/acre but labelled q/ha
miss_y = rng.random(ns) < 0.010
yv = df.y_true.values.copy()
lab = unit_lab[season_key.values]
yv = np.where(lab == "kg/acre", yv * 40.47, np.where(lab == "t/ha", yv / 10, yv))
yv = np.where(mislabel[season_key.values], df.y_true.values * 40.47, yv)
yv = np.where(miss_y[season_key.values], np.nan, yv)
df["yield_value"] = yv.round(2)
df["yield_unit"] = lab

# leakage columns that exist only after harvest
df["crop_cutting_estimate_q_ha"] = (df.y_true * np.exp(rng.normal(0, 0.03, ns))[season_key.values]).round(2)
df["production_tonnes"] = (df.y_true * df.area_ha / 10).round(1)
df["procured_qty_tonnes"] = (df.production_tonnes * np.exp(rng.normal(-1.2, 0.2, ns))[season_key.values]).round(1)

# ----------------------------------------------------------------------------- inject messiness
# missing monsoon rainfall (MNAR: heavy-rain weeks more likely to go missing - gauge overflow / washed-out access)
p_miss = np.where(df.week_no <= 17, 0.10 + 0.08 * (df.rainfall_mm > 60), 0.004)
miss = rng.random(len(df)) < p_miss
gap_keys = df.groupby(["di", "b", "yi"]).ngroup()
gap_blocks = rng.random(gap_keys.max() + 1) < 0.08
start = rng.integers(2, 12, gap_keys.max() + 1)
gap = gap_blocks[gap_keys.values] & (df.week_no.values >= start[gap_keys.values]) & (df.week_no.values < start[gap_keys.values] + 5)
df.loc[miss | gap, "rainfall_mm"] = np.nan
sent = rng.random(len(df)) < 0.002
df.loc[sent & df.rainfall_mm.notna(), "rainfall_mm"] = -999.0
df["rainfall_mm"] = df.rainfall_mm.round(1)
df["temp_max_c"] = df.temp_max_c.round(1)
# random per-kg price rows
kgrow = rng.random(len(df)) < 0.015
df.loc[kgrow, "mandi_price"] = df.loc[kgrow, "mandi_price"] / 100.0
df["mandi_price"] = df.mandi_price.round(2)
# missing soil tests (block-year level)
for col in ["soil_oc_pct", "soil_n_kg_ha", "soil_p_kg_ha", "soil_k_kg_ha", "soil_ph"]:
    gm = rng.random(gap_keys.max() + 1) < 0.09
    df.loc[gm[gap_keys.values], col] = np.nan
    df[col] = df[col].round(2)
# messy labels
def mess(series, variants):
    s = series.copy()
    m = rng.random(len(s)) < 0.03
    s[m] = [variants[v][rng.integers(0, len(variants[v]))] if v in variants else v for v in s[m]]
    return s
df["crop"] = mess(df.crop, {"Soybean": ["soybean ", "SOYBEAN", "Soya bean"], "Cotton": ["cotton", "COTTON "], "Tur": ["tur", "Arhar/Tur"],
                            "Rice": ["rice", "Paddy"], "Wheat": ["wheat", "WHEAT"], "Gram": ["gram", "Chana"]})
df["district"] = mess(df.district, {d: [d.lower(), d.upper() + " ", " " + d] for d in DISTRICTS})

cols = ["week_start_date", "ag_year", "week_no", "district", "block", "mandi_name", "crop", "seed_variety", "area_ha",
        "rainfall_mm", "temp_max_c", "soil_ph", "soil_n_kg_ha", "soil_p_kg_ha", "soil_k_kg_ha", "soil_oc_pct",
        "mandi_price", "yield_value", "yield_unit", "crop_cutting_estimate_q_ha", "production_tonnes", "procured_qty_tonnes"]
out = df[cols].copy()
out.insert(0, "record_id", np.arange(1, len(out) + 1))
dups = out.sample(frac=0.016, random_state=SEED)
out = pd.concat([out, dups]).sort_values("record_id", kind="stable").reset_index(drop=True)

path = Path(__file__).resolve().parents[1] / "data" / "raw" / "agri_raw.csv.gz"
out.to_csv(path, index=False, compression="gzip")
print("rows:", len(out), "| cols:", out.shape[1], "| saved:", path)
