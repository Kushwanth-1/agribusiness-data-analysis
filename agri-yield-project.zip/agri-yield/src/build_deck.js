// 8-slide findings deck. All numbers are read from reports/metrics.json (written by the notebook).
const pptxgen = require("pptxgenjs");
const fs = require("fs");
const path = require("path");
const { applyTheme } = require("/mnt/skills/public/pptx/scripts/apply_theme.js");

const ROOT = path.resolve(__dirname, "..");
const m = JSON.parse(fs.readFileSync(path.join(ROOT, "reports/metrics.json"), "utf8"));
const FIG = (f) => path.join(ROOT, "reports/figures", f);

const THEME = {
  name: "Agri Forecast",
  headFontFace: "Cambria",
  bodyFontFace: "Calibri",
  colors: { dk1: "1F2A24", lt1: "FFFFFF", dk2: "14442F", lt2: "EDF4EE", accent1: "1F6B47", accent2: "D9961A", accent3: "B5482A",
            accent4: "2E7D9A", accent5: "7A8F82", accent6: "5B4A8C", hlink: "2E7D9A", folHlink: "5B4A8C" },
};
const HEX = { dk: "14442F", green: "1F6B47", gold: "D9961A", rust: "B5482A", blue: "2E7D9A", sage: "7A8F82", ink: "1F2A24", tint: "EDF4EE", white: "FFFFFF" };

const pres = new pptxgen();
pres.layout = "LAYOUT_16x9"; // 10 x 5.625 in
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
pres.title = "Agri Predictive Analytics Model - findings";
pres.author = "Kalla Kushwanth";
const C = pres.SchemeColor;

pres.defineSlideMaster({
  title: "DARK",
  background: { color: HEX.dk },
  objects: [],
  slideNumber: undefined,
});
pres.defineSlideMaster({
  title: "CONTENT",
  background: { color: HEX.white },
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: 0.5, y: 0.3, w: 9.0, h: 0.75, fontFace: "Cambria", fontSize: 34, bold: true, color: HEX.dk, valign: "middle", margin: 0 }, text: "" } },
  ],
  slideNumber: { x: 9.2, y: 5.25, w: 0.5, h: 0.25, fontFace: "Calibri", fontSize: 10, color: HEX.sage },
});

const num = (x, d = 1) => Number(x).toFixed(d);
const F = m.final;
const total = (m.split.train + m.split.val + m.split.test);

function addTitle(slide, text) { slide.addText(text, { placeholder: "title" }); }
function card(slide, x, y, w, h, fill) {
  slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: fill || HEX.tint }, line: { color: fill || HEX.tint, width: 0.5 } });
}

// ---------------------------------------------------------------- 1 title
pres.addSection({ title: "Opening" });
let s = pres.addSlide({ masterName: "DARK", sectionTitle: "Opening" });
s.addText("Agri Predictive Analytics Model", { x: 0.6, y: 1.35, w: 8.8, h: 0.9, fontFace: "Cambria", fontSize: 42, bold: true, color: HEX.white, margin: 0, isTextBox: true });
s.addText("Forecasting district-level crop yield at week 20 - and explaining why", { x: 0.6, y: 2.3, w: 8.4, h: 0.6, fontFace: "Calibri", fontSize: 20, color: "CFE3D6", margin: 0, isTextBox: true });
s.addText("Yuva Intern - Junior Data Scientist Internship (Nagpur) - Findings deck", { x: 0.6, y: 3.6, w: 8.4, h: 0.35, fontFace: "Calibri", fontSize: 14, color: HEX.gold, margin: 0, isTextBox: true });
s.addText("Built on simulated data that reproduces the brief's problems: results show the method, not real Vidarbha yields.", { x: 0.6, y: 4.6, w: 8.4, h: 0.5, fontFace: "Calibri", fontSize: 12, italic: true, color: "9DBBA8", margin: 0, isTextBox: true });
s.addNotes("Open with the framing: this is a method demonstration on simulated data built to match the brief. The forecast date is the end of week 20, about mid-October.");

// ---------------------------------------------------------------- 2 summary
pres.addSection({ title: "Findings" });
s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Findings" });
addTitle(s, "The model beats the baseline");
const stats = [
  [`${num(F.imp_val, 0)}% / ${num(F.imp_test, 0)}%`, "better than the 3-year average on validation / test", HEX.green],
  [`${num(F.test.MAE_district, 2)} q/ha`, "test error per district-crop (7.2% of yield)", HEX.blue],
  [`${num(m.shortfall.test_recall * 100, 0)}%`, `of shortfalls caught on test (precision ${num(m.shortfall.test_precision * 100, 0)}%)`, HEX.gold],
];
stats.forEach((st, i) => {
  const x = 0.5 + i * 3.05;
  card(s, x, 1.3, 2.9, 1.75);
  s.addText(st[0], { x: x + 0.15, y: 1.4, w: 2.6, h: 0.8, fontFace: "Cambria", fontSize: 34, bold: true, color: st[2], margin: 0, isTextBox: true });
  s.addText(st[1], { x: x + 0.15, y: 2.2, w: 2.6, h: 0.75, fontFace: "Calibri", fontSize: 14, color: HEX.ink, margin: 0, valign: "top", isTextBox: true });
});
s.addText([
  { text: `Forecast issued at week 20 (mid-October) from weeks 1-20 plus past seasons only`, options: { bullet: true, breakLine: true } },
  { text: `${m.raw_rows.toLocaleString()} raw weekly rows reduced to ${total.toLocaleString()} block-crop seasons, ${m.n_features} features`, options: { bullet: true, breakLine: true } },
  { text: `One goal not met: test error rose ${num(F.gap_test_vs_val_pct, 0)}% above validation, traced mainly to unusually wet seasons`, options: { bullet: true } },
], { x: 0.5, y: 3.3, w: 9.0, h: 1.6, fontFace: "Calibri", fontSize: 16, color: HEX.ink, paraSpaceAfter: 8, valign: "top", margin: 0, isTextBox: true });
s.addNotes("Both validation and test beat the baseline by well over the 15% target. The 5% stability goal was not met; the next slides explain why.");

// ---------------------------------------------------------------- 3 data problems
s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Findings" });
addTitle(s, "Four data problems fixed");
const cl = m.cleaning;
const issues = [
  [cl.duplicates_removed.toLocaleString(), "duplicate rows removed", "Exact copies, including the record ID."],
  [cl.price_per_kg_rows.toLocaleString(), "prices entered per kg", "Found by comparing to other mandis in the same week, then x100 to per quintal."],
  [(cl.yield_unit_converted_rows + cl.yield_mislabelled_rows).toLocaleString(), "yield values in wrong units", `${cl.yield_unit_converted_rows.toLocaleString()} kg/acre or t/ha converted, ${cl.yield_mislabelled_rows.toLocaleString()} mislabelled caught by size.`],
  [cl.rain_missing_rows.toLocaleString(), "rainfall readings missing", "Heavy-rain weeks go missing most, so a plain average would understate rain."],
];
issues.forEach((it, i) => {
  const col = i % 2, row = Math.floor(i / 2);
  const x = 0.5 + col * 4.6, y = 1.3 + row * 1.85;
  card(s, x, y, 4.4, 1.65);
  s.addText(it[0], { x: x + 0.2, y: y + 0.1, w: 4.0, h: 0.6, fontFace: "Cambria", fontSize: 30, bold: true, color: i === 3 ? HEX.rust : HEX.green, margin: 0, isTextBox: true });
  s.addText(it[1], { x: x + 0.2, y: y + 0.68, w: 4.0, h: 0.3, fontFace: "Calibri", fontSize: 14, bold: true, color: HEX.ink, margin: 0, isTextBox: true });
  s.addText(it[2], { x: x + 0.2, y: y + 0.98, w: 4.0, h: 0.6, fontFace: "Calibri", fontSize: 12, color: HEX.ink, margin: 0, valign: "top", isTextBox: true });
});
s.addNotes("Every fix is detected from the data, not hard-coded. Missing rainfall was filled from the same gauge under other crops, then neighbouring blocks.");

// ---------------------------------------------------------------- 4 leakage
s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Findings" });
addTitle(s, "Leakage makes models lie");
const ld = m.leak_demo;
s.addChart(pres.charts.BAR, [{ name: "MAE (log-ratio)", labels: ["Honest time split", "Random shuffled CV", "Leaky columns kept"], values: ld.map((r) => r["MAE (log-ratio)"]) }], {
  x: 0.5, y: 1.25, w: 5.2, h: 3.7, barDir: "col", chartColors: [HEX.green, HEX.gold, HEX.rust], showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 12, dataLabelColor: HEX.ink,
  dataLabelFontFace: "Calibri", dataLabelFormatCode: "0.000", showTitle: true, title: "Forecast error (lower looks better)", titleFontSize: 12, titleColor: HEX.ink, titleFontFace: "Calibri",
  catAxisLabelColor: HEX.ink, catAxisLabelFontSize: 11, catAxisLabelFontFace: "Calibri", valAxisLabelColor: HEX.sage, valAxisLabelFontSize: 10, valAxisLabelFontFace: "Calibri",
  valGridLine: { color: "DDE7E0", size: 0.5 }, catGridLine: { style: "none" }, showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 0.14, varyColors: true,
});
s.addText([
  { text: "Too good to be true", options: { bold: true, breakLine: true, fontSize: 16 } },
  { text: `Random splits look ${num((1 - ld[1]["MAE (log-ratio)"] / ld[0]["MAE (log-ratio)"]) * 100, 0)}% better and leaky columns ${num((1 - ld[2]["MAE (log-ratio)"] / ld[0]["MAE (log-ratio)"]) * 100, 0)}% better - neither exists on forecast day.`, options: { breakLine: true, paraSpaceAfter: 10 } },
  { text: "What I excluded", options: { bold: true, breakLine: true, fontSize: 16 } },
  { text: "Production, procurement and crop-cutting estimate (they contain the answer), season-total rainfall, post-harvest prices.", options: { breakLine: true, paraSpaceAfter: 10 } },
  { text: "Split", options: { bold: true, breakLine: true, fontSize: 16 } },
  { text: "Train on 2006 to 2019, validate on 2020 to 2022, test on 2023 to 2025.", options: {} },
], { x: 6.0, y: 1.3, w: 3.5, h: 3.6, fontFace: "Calibri", fontSize: 14, color: HEX.ink, valign: "top", margin: 0, isTextBox: true });
s.addNotes("Correlations of the post-harvest columns with yield are 0.93 to 1.00. Random cross-validation lets the model see other blocks from the same year, which share weather.");

// ---------------------------------------------------------------- 5 models
s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Findings" });
addTitle(s, "Gradient boosting wins");
const vt = m.val_table.slice().sort((a, b) => a.MAE_district - b.MAE_district);
s.addChart(pres.charts.BAR, [{ name: "Validation MAE (q/ha)", labels: vt.map((r) => r.model.replace(" (3-yr rolling mean)", "").replace(" (linear)", "")), values: vt.map((r) => r.MAE_district) }], {
  x: 0.5, y: 1.25, w: 5.6, h: 3.7, barDir: "bar", chartColors: vt.map((r) => (r.model.includes("tuned") ? HEX.green : r.model.includes("Baseline") ? HEX.sage : "A9C7B4")), showValue: true,
  dataLabelPosition: "outEnd", dataLabelFontSize: 11, dataLabelColor: HEX.ink, dataLabelFontFace: "Calibri", dataLabelFormatCode: "0.00", showTitle: true, title: "Validation error per district-crop (q/ha)", titleFontSize: 12,
  titleColor: HEX.ink, titleFontFace: "Calibri", catAxisLabelColor: HEX.ink, catAxisLabelFontSize: 11, catAxisLabelFontFace: "Calibri", catAxisOrientation: "maxMin", valAxisLabelColor: HEX.sage, valAxisLabelFontSize: 10, valAxisLabelFontFace: "Calibri",
  valGridLine: { color: "DDE7E0", size: 0.5 }, catGridLine: { style: "none" }, showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 2, varyColors: true,
});
const tiles = [
  [`${num(F.test_base.MAE_district, 2)} -> ${num(F.test.MAE_district, 2)}`, "test q/ha: baseline vs final model"],
  [`${num(F.imp_val, 0)}% and ${num(F.imp_test, 0)}%`, "improvement vs baseline, validation and test"],
];
tiles.forEach((t, i) => {
  const y = 1.3 + i * 1.3;
  card(s, 6.4, y, 3.1, 1.15);
  s.addText(t[0], { x: 6.55, y: y + 0.08, w: 2.8, h: 0.5, fontFace: "Cambria", fontSize: 22, bold: true, color: HEX.green, margin: 0, isTextBox: true });
  s.addText(t[1], { x: 6.55, y: y + 0.62, w: 2.8, h: 0.45, fontFace: "Calibri", fontSize: 12, color: HEX.ink, margin: 0, valign: "top", isTextBox: true });
});
s.addText("Linear model loses to the baseline: yield reacts to rainfall in a curve, not a line.", { x: 6.4, y: 3.95, w: 3.1, h: 0.9, fontFace: "Calibri", fontSize: 14, color: HEX.ink, margin: 0, valign: "top", isTextBox: true });
s.addNotes("Baseline is the 3-year block-crop rolling mean. Models were compared with expanding-window cross-validation, then on untouched validation years. Tuning added little in CV but helped validation district error from 0.90 to 0.85.");

// ---------------------------------------------------------------- 6 drivers
s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Findings" });
addTitle(s, "What drives the forecast");
const fam = Object.entries(m.family_share).sort((a, b) => b[1] - a[1]);
s.addChart(pres.charts.BAR, [{ name: "Share of attribution (%)", labels: fam.map((f) => f[0].replace(" / block & variety effect", "").replace(" (area, trend)", "")), values: fam.map((f) => f[1]) }], {
  x: 0.5, y: 1.25, w: 4.7, h: 3.7, barDir: "bar", chartColors: [HEX.green], showValue: true, dataLabelPosition: "outEnd", dataLabelFontSize: 11, dataLabelColor: HEX.ink, dataLabelFontFace: "Calibri", dataLabelFormatCode: "0.0",
  showTitle: true, title: "Share of Shapley attribution (%)", titleFontSize: 12, titleColor: HEX.ink, titleFontFace: "Calibri", catAxisLabelColor: HEX.ink, catAxisLabelFontSize: 11, catAxisLabelFontFace: "Calibri", catAxisOrientation: "maxMin",
  valAxisLabelColor: HEX.sage, valAxisLabelFontSize: 10, valAxisLabelFontFace: "Calibri", valGridLine: { color: "DDE7E0", size: 0.5 }, catGridLine: { style: "none" }, showLegend: false, valAxisMinVal: 0, valAxisMaxVal: 35,
});
s.addText([
  { text: "Monsoon rainfall, weeks 1-17: extremes in either direction cut yield", options: { bullet: true, breakLine: true } },
  { text: "Last harvest's price vs now: a market signal of local supply", options: { bullet: true, breakLine: true } },
  { text: "3-year rain average: soil-moisture memory", options: { bullet: true, breakLine: true } },
  { text: "Price trend vs last year: farmers invest after good prices", options: { bullet: true, breakLine: true } },
  { text: "Tur: the crop most hurt by wet monsoons", options: { bullet: true, breakLine: true } },
  { text: "Caveat: price features are signals, not causes", options: { bold: true, color: HEX.rust } },
], { x: 5.5, y: 1.3, w: 4.0, h: 3.6, fontFace: "Calibri", fontSize: 14, color: HEX.ink, paraSpaceAfter: 8, valign: "top", margin: 0, isTextBox: true });
s.addNotes("Shapley values were estimated by permutation sampling because the shap package was not installable offline; the notebook uses shap automatically when it is present. Dry-spell length, soil and heat ranked lower than the EDA story suggested.");

// ---------------------------------------------------------------- 7 actions
pres.addSection({ title: "Action" });
s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Action" });
addTitle(s, "From forecast to action");
const iw = 5.2, ih = iw * 598 / 1170;
s.addImage({ path: FIG("08_procurement_heatmap.png"), x: 0.5, y: 1.3, w: iw, h: ih, altText: "Heatmap of predicted 2025 supply versus 3-year normal by district and crop" });
s.addText("Forecast issued at week 20, 2025 season", { x: 0.5, y: 1.3 + ih + 0.05, w: iw, h: 0.3, fontFace: "Calibri", fontSize: 11, color: HEX.sage, margin: 0, isTextBox: true });
const ac = m.actions_counts;
const rules = [
  [`BOOK EARLY (${ac["BOOK EARLY: forward contracts / farm-gate buying"]})`, "Supply forecast 4%+ below normal: Bhandara kharif crops, Chandrapur soybean, wheat, gram.", HEX.rust],
  [`WAIT (${ac["WAIT: buy spot, expect softer prices"]})`, "4%+ above normal: tur in Wardha, Amravati and Yavatmal (+13 to +14%).", HEX.green],
  [`ROUTINE (${ac["ROUTINE: normal procurement plan"]})`, "Within 4% of normal.", HEX.sage],
];
rules.forEach((r, i) => {
  const y = 1.3 + i * 0.95;
  card(s, 5.9, y, 3.6, 0.85);
  s.addText(r[0], { x: 6.05, y: y + 0.05, w: 3.3, h: 0.28, fontFace: "Calibri", fontSize: 14, bold: true, color: r[2], margin: 0, isTextBox: true });
  s.addText(r[1], { x: 6.05, y: y + 0.33, w: 3.3, h: 0.5, fontFace: "Calibri", fontSize: 11, color: HEX.ink, margin: 0, valign: "top", isTextBox: true });
});
s.addText([
  { text: `Hindsight (2025 actuals): direction right in ${num(m.hindsight.direction_hit * 100, 0)}% of 36 pairs. Bhandara kharif shortfalls were real (tur forecast -58%, actual -56%); its rabi flags were wrong (gram forecast -31%, actual +10%).`, options: {} },
], { x: 0.5, y: 4.55, w: 9.0, h: 0.7, fontFace: "Calibri", fontSize: 12, color: HEX.ink, margin: 0, valign: "top", isTextBox: true });
s.addNotes("Treat rabi crop flags in unusually wet years as low confidence. Priority score combines expected shortfall with price momentum; it is a heuristic, not an optimiser.");

// ---------------------------------------------------------------- 8 limits
s = pres.addSlide({ masterName: "CONTENT", sectionTitle: "Action" });
addTitle(s, "Limits and next steps");
const rd = m.range_diag, w = m.wrong;
card(s, 0.5, 1.25, 4.4, 3.45);
s.addText([
  { text: "Scorecard", options: { bold: true, fontSize: 16, breakLine: true } },
  { text: `Beat baseline by 15%: met (${num(F.imp_val, 0)}% / ${num(F.imp_test, 0)}%)`, options: { bullet: true, breakLine: true } },
  { text: `Test within 5% of validation: not met (+${num(F.gap_test_vs_val_pct, 0)}%; baseline also worsened 17%)`, options: { bullet: true, breakLine: true } },
  { text: "Top drivers sensible: yes, with the price caveat", options: { bullet: true, breakLine: true } },
  { text: `Main source of the gap: unusually wet seasons doubled (${num(rd.wet_share_val * 100, 0)}% to ${num(rd.wet_share_test * 100, 0)}% of rows); error ${num(rd.mape_wet_test, 0)}% vs ${num(rd.mape_normal_test, 0)}% in normal seasons`, options: { bullet: true, breakLine: true } },
  { text: "Simple recalibration made forecasts worse, so I would not ship it", options: { bullet: true } },
], { x: 0.7, y: 1.35, w: 4.0, h: 3.6, fontFace: "Calibri", fontSize: 13, color: HEX.ink, paraSpaceAfter: 6, valign: "top", margin: 0, isTextBox: true });
card(s, 5.1, 1.25, 4.4, 3.45);
s.addText([
  { text: "One wrong prediction", options: { bold: true, fontSize: 16, breakLine: true } },
  { text: `${w.block.replace("WRD-", "Wardha ")}, soybean, ${w.year}: forecast ${num(w.pred, 1)}, actual ${num(w.actual, 1)} q/ha`, options: { bold: true, breakLine: true, paraSpaceAfter: 6 } },
  { text: `Monsoon was ${num(w.rel_wet, 2)}x the block's history. Similar seasons landed near ${num(w.analog_ratio, 2)}x baseline; this one hit ${num(w.actual_ratio, 2)}x.`, options: { breakLine: true, paraSpaceAfter: 6 } },
  { text: `The model said ${num(w.model_ratio, 2)}x: price features outweighed rainfall, and a good 2021 inflated the baseline.`, options: { breakLine: true, paraSpaceAfter: 6 } },
  { text: "Next: crop-specific wet-season features and a hybrid model, tested on a fresh hold-out", options: { bold: true, color: HEX.green } },
], { x: 5.3, y: 1.35, w: 4.0, h: 3.6, fontFace: "Calibri", fontSize: 13, color: HEX.ink, valign: "top", margin: 0, isTextBox: true });
s.addNotes("Late-season weather was checked and ruled out for this block-year. A hybrid linear plus boosting model did worse on validation, so it was not selected, though it looked better on test; that needs a fresh hold-out.");

(async () => {
  const out = path.join(ROOT, "deliverables/Findings_Deck_8_slides.pptx");
  await pres.writeFile({ fileName: out });
  await applyTheme(out, THEME);
  console.log("wrote", out);
})();
