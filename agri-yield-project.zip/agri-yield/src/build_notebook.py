"""Execute notebooks/analysis.py cell by cell and write notebooks/agri_yield_analysis.ipynb with outputs embedded.
Usage (from repo root):  python src/build_notebook.py
"""
import base64, io, json, sys, time, traceback, contextlib
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
src = (ROOT / "notebooks" / "analysis.py").read_text().split("\n")

cells, cur, kind = [], [], None
def flush():
    global cur, kind
    if kind is not None:
        body = "\n".join(cur).strip("\n")
        if kind == "markdown":
            body = "\n".join(l[2:] if l.startswith("# ") else l.lstrip("#") for l in body.split("\n"))
        if body.strip():
            cells.append((kind, body))
    cur, kind = [], None
for line in src:
    if line.startswith("# %%"):
        flush(); kind = "markdown" if "[markdown]" in line else "code"
    else:
        cur.append(line)
flush()

ns = {"__name__": "__main__"}
nb_cells, count = [], 0
for kind, body in cells:
    if kind == "markdown":
        nb_cells.append({"cell_type": "markdown", "metadata": {}, "source": body.splitlines(True)})
        continue
    count += 1
    buf = io.StringIO(); t0 = time.time(); outputs = []
    with contextlib.redirect_stdout(buf):
        try:
            exec(compile(body, f"<cell {count}>", "exec"), ns)
        except Exception:
            traceback.print_exc(file=buf)
            print(buf.getvalue()); print(f"FAILED in cell {count}", file=sys.stderr); sys.exit(1)
    text = buf.getvalue()
    if text:
        outputs.append({"output_type": "stream", "name": "stdout", "text": text.splitlines(True)})
    for n in plt.get_fignums():
        b = io.BytesIO(); plt.figure(n).savefig(b, format="png", dpi=110, bbox_inches="tight")
        outputs.append({"output_type": "display_data", "metadata": {}, "data": {"image/png": base64.b64encode(b.getvalue()).decode(), "text/plain": ["<Figure>"]}})
    plt.close("all")
    nb_cells.append({"cell_type": "code", "metadata": {}, "execution_count": count, "source": body.splitlines(True), "outputs": outputs})
    print(f"cell {count} ok ({time.time() - t0:.1f}s)", file=sys.stderr)

nb = {"cells": nb_cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                                      "language_info": {"name": "python"}}, "nbformat": 4, "nbformat_minor": 5}
out = ROOT / "notebooks" / "agri_yield_analysis.ipynb"
out.write_text(json.dumps(nb, indent=1))
print("wrote", out, f"({out.stat().st_size / 1e6:.1f} MB)", file=sys.stderr)
