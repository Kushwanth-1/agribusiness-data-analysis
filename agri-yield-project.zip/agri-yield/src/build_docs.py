"""Write reports/model_card.md, README.md, requirements.txt, .gitignore and deliverables/Project_Description.txt from reports/metrics.json."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
m = json.load(open(ROOT / "reports/metrics.json"))
F, RD, W = m["final"], m["range_diag"], m["wrong"]
n = lambda x, d=1: f"{x:.{d}f}"
bp = m["best_params"]

card = f"""# Model card: Agri yield forecaster (week-20)

## Model details
- **Task:** forecast season yield (q/ha) for a block x crop at the end of week 20 of the agricultural year (about mid-October); reported at district x crop level.
- **Model:** HistGradientBoostingRegressor (scikit-learn) on target log(yield / 3-year block-crop rolling mean); prediction = rolling mean x exp(output).
- **Tuned parameters:** {json.dumps(bp)}
- **Trained on:** seasons 2006-2022 (selected on 2020-2022 validation, refit on train+validation). File: `models/yield_model.joblib` (dict with `model`, `features`, `cutoff_week`).
- **Features:** {m['n_features']} (rainfall, temperature, soil, price signals, yield history, past-only target encodings, crop and district one-hot). See notebook section 5.

## Intended use
Early procurement planning (which district-crop pairs to book early, wait on, or buy routinely). Not intended for insurance, credit decisions about individual farmers, or any use that needs farm-level accuracy.

## Data
Seeded **synthetic** dataset (`src/generate_data.py`), {m['raw_rows']:,} raw weekly rows, 6 districts, 48 blocks, 6 crops, 2003-2025, built to contain the data problems in the brief. **No real farm data was used.** Results demonstrate the method only.

## Evaluation (district x crop x year level)
| | Validation 2020-22 | Test 2023-25 |
|---|---|---|
| Model MAE (q/ha) | {n(F['val']['MAE_district'],3)} | {n(F['test']['MAE_district'],3)} |
| Baseline MAE (3-year rolling mean) | {n(F['val_base']['MAE_district'],3)} | {n(F['test_base']['MAE_district'],3)} |
| Improvement vs baseline | {n(F['imp_val'])}% | {n(F['imp_test'])}% |
| WAPE | {n(F['val']['WAPE_district_%'],2)}% | {n(F['test']['WAPE_district_%'],2)}% |
| Shortfall recall at precision | {n(m['shortfall']['val_recall']*100,0)}% at {n(m['shortfall']['val_precision']*100,0)}% | {n(m['shortfall']['test_recall']*100,0)}% at {n(m['shortfall']['test_precision']*100,0)}% |

**Success criteria:** beating the baseline by 15% is met. Test within 5% of validation is **not met** (test MAE {n(F['gap_test_vs_val_pct'],0)}% above validation).

## Known weaknesses
- **Unusually wet seasons** (rainfall above 1.4x the block's own history): average error {n(RD['mape_wet_test'])}% vs {n(RD['mape_normal_test'])}% in normal seasons, bias {n(RD['bias_wet_test'])}% (the model forecasts too large a collapse). Worst in irrigated Bhandara and for rabi crops. These seasons doubled in frequency in the test years.
- **Price features** (second most important family) are market signals and need timely mandi data for weeks 1-20.
- **Shift:** the price ratio to last year and monsoon rainfall have PSI above 0.25 between train and test; monitor them.
- **Simple recalibration** (adding half of last season's district-crop residual) made forecasts worse and is not used.
- Farm-size groups show similar error; district and weather regime are the fairness-relevant axes here.

## Explainability
Shapley values (permutation-sampling estimator; `shap.TreeExplainer` is used automatically if installed) and partial-dependence plots. Attribution shares: {', '.join(f'{k} {v}%' for k, v in m['family_share'].items())}.

## Ethical and practical notes
Forecasts are decision support for a buyer, so errors affect farmers indirectly through procurement timing and prices. Do not use rabi shortfall flags in unusually wet years without human review. Retrain annually and re-check bias by district.
"""
(ROOT / "reports/model_card.md").write_text(card)

readme = f"""# Agri Predictive Analytics Model

Forecast district-level crop yield at **week 20** of the agricultural year and explain the drivers, for a fictional Nagpur agritech start-up (Yuva Intern project).

> **Data note:** the project brief ships no dataset, so `src/generate_data.py` builds a seeded synthetic one (~{m['raw_rows']:,} rows) containing the problems the brief lists. Results show the method, not real Vidarbha yields.

## Results
- Final model (gradient boosting) beats the 3-year-average baseline by **{n(F['imp_val'])}%** on validation and **{n(F['imp_test'])}%** on test (test MAE {n(F['test']['MAE_district'],2)} q/ha per district-crop).
- Not met: test error is {n(F['gap_test_vs_val_pct'],0)}% above validation, largely traced to unusually wet seasons (see notebook section 9b).
- Main drivers: monsoon rainfall and price signals.

## Repository layout
```
src/generate_data.py          synthetic raw data (seeded)
src/build_notebook.py         runs notebooks/analysis.py and writes the executed notebook
src/build_deck.js, build_report.js, build_docs.py   build the deck, Word report and docs
notebooks/analysis.py         the full analysis (cell-marked script)
notebooks/agri_yield_analysis.ipynb   executed notebook with outputs and figures
models/yield_model.joblib     trained model + feature list
reports/model_card.md, metrics.json, test_predictions.csv, figures/
data/raw/agri_raw.csv.gz      generated raw data
data/processed/model_table.csv.gz   modelling table
deliverables/                 Word report, 8-slide deck, project description
```

## Reproduce
```bash
pip install -r requirements.txt
python src/generate_data.py      # writes data/raw/agri_raw.csv.gz
python src/build_notebook.py     # runs the analysis, writes notebooks/agri_yield_analysis.ipynb
```
`shap` is optional: the notebook uses it if installed, otherwise a permutation-sampling Shapley estimator.

## Method in one paragraph
Clean (duplicates, labels, per-kg prices, yield units, rainfall imputation from neighbouring blocks) -> leakage audit (post-harvest columns, season totals, post-harvest prices excluded) -> time-aware split (train 2006-2019, validation 2020-2022, test 2023-2025) -> {m['n_features']} features with past-only target encoding -> compare baseline, ridge, random forest, gradient boosting with expanding-window CV -> tune the best -> Shapley and partial dependence -> procurement actions -> fairness and stability checks -> one wrong prediction explained.
"""
(ROOT / "README.md").write_text(readme)
(ROOT / "requirements.txt").write_text("numpy>=2.0\npandas>=2.2\nscikit-learn>=1.4\nscipy>=1.11\nmatplotlib>=3.8\nseaborn>=0.13\njoblib>=1.3\n# optional\nshap\n")
(ROOT / ".gitignore").write_text("__pycache__/\n*.pyc\n.ipynb_checkpoints/\n")

desc = (f"This project builds an early-warning yield forecast for a fictional Nagpur agritech start-up. The goal is to predict district-level crop yield at the end of week 20 of the agricultural year (about mid-October), early enough to guide procurement, and to explain the drivers to business users. "
        f"No dataset came with the brief, so I generated a seeded synthetic dataset of about {round(m['raw_rows'], -4):,} weekly rows across 6 districts and 6 crops that reproduces the problems described: prices mixed between per quintal and per kg, missing monsoon rainfall, yield recorded in wrong units, plus duplicates and messy labels. "
        f"I cleaned each issue with rules detected from the data, audited columns for leakage (post-harvest production, procurement and price columns), and used a time-aware split: train 2006 to 2019, validation 2020 to 2022, test 2023 to 2025. "
        f"I engineered {m['n_features']} features, including lag, rolling and ratio features, with past-only target encoding for high-cardinality categories. I compared a baseline, ridge regression, random forest and gradient boosting using expanding-window cross-validation, then tuned the best one. "
        f"The final model beats the 3-year-average baseline by {n(F['imp_val'],0)}% on validation and {n(F['imp_test'],0)}% on test (test error {n(F['test']['MAE_district'],2)} q/ha per district-crop), and Shapley values and partial dependence show rainfall and price signals as the main drivers. "
        f"I converted forecasts into procurement actions (book early, wait, routine) and checked them against the 2025 actuals. I also report what did not work: test error was {n(F['gap_test_vs_val_pct'],0)}% above validation largely in unusually wet seasons, which doubled in frequency, so the stability goal was missed; a simple recalibration made forecasts worse; and I explain one wrong prediction in detail. "
        f"All results come from simulated data, so they demonstrate the method rather than real yields.")
words = len(desc.split())
assert words >= 200, words
(ROOT / "deliverables/Project_Description.txt").write_text(desc + "\n")
print("description words:", words)
