// Word project report. Numbers come from reports/metrics.json; figures from reports/figures.
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, HeadingLevel, AlignmentType, WidthType, ShadingType, BorderStyle,
  LevelFormat, PageBreak, Footer, PageNumber,
} = require("docx");

const ROOT = path.resolve(__dirname, "..");
const m = JSON.parse(fs.readFileSync(path.join(ROOT, "reports/metrics.json"), "utf8"));
const png = (f) => fs.readFileSync(path.join(ROOT, "reports/figures", f));
const dims = (buf) => ({ w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) });
const n = (x, d = 1) => { const v = Number(x); return (v < 0 && Number(Math.abs(v).toFixed(d)) !== 0 ? "\u2212" : "") + Math.abs(v).toFixed(d); };
const F = m.final, W = m.wrong, RD = m.range_diag, CL = m.cleaning;

const GREEN = "14442F", INK = "1F2A24", TINT = "EDF4EE", GREY = "5F6F66";
const CONTENT_W = 9746; // A4 with 0.75 in margins

const p = (text, opts = {}) => new Paragraph({ spacing: { after: 120, line: 276 }, ...opts, children: Array.isArray(text) ? text : [new TextRun({ text, ...(opts.run || {}) })] });
const b = (text) => new TextRun({ text, bold: true });
const bullet = (children) => new Paragraph({ numbering: { reference: "bul", level: 0 }, spacing: { after: 80, line: 270 }, children: Array.isArray(children) ? children : [new TextRun(children)] });
const h1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] });
const h2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] });
function img(file, widthPx, caption) {
  const buf = png(file), d = dims(buf), h = Math.round((widthPx * d.h) / d.w);
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 60 }, children: [new ImageRun({ type: "png", data: buf, transformation: { width: widthPx, height: h }, altText: { title: caption, description: caption, name: file } })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: caption, italics: true, size: 18, color: GREY })] }),
  ];
}
function table(cols, rows, widths, opts = {}) {
  const border = { style: BorderStyle.SINGLE, size: 4, color: "C9D6CD" };
  const borders = { top: border, bottom: border, left: border, right: border };
  const cell = (t, w, head, align) => new TableCell({
    width: { size: w, type: WidthType.DXA }, borders, margins: { top: 60, bottom: 60, left: 100, right: 100 },
    shading: head ? { fill: GREEN, type: ShadingType.CLEAR, color: "auto" } : undefined,
    children: [new Paragraph({ alignment: align || AlignmentType.LEFT, children: [new TextRun({ text: String(t), bold: head, color: head ? "FFFFFF" : INK, size: 19 })] })],
  });
  return new Table({
    width: { size: widths.reduce((a, c) => a + c, 0), type: WidthType.DXA }, columnWidths: widths,
    rows: [new TableRow({ tableHeader: true, children: cols.map((c, i) => cell(c, widths[i], true, i > 0 && opts.numeric ? AlignmentType.RIGHT : AlignmentType.LEFT)) }),
      ...rows.map((r) => new TableRow({ cantSplit: true, children: r.map((c, i) => cell(c, widths[i], false, i > 0 && opts.numeric ? AlignmentType.RIGHT : AlignmentType.LEFT)) }))],
  });
}
const gap = () => new Paragraph({ spacing: { after: 160 }, children: [] });

const vt = m.val_table.slice().sort((a, b2) => a.MAE_district - b2.MAE_district);
const fairD = m.fair.district, fairC = m.fair.crop, fairS = m.fair.size_group;

const body = [
  // ------------------------------------------------ cover
  new Paragraph({ spacing: { before: 1800, after: 120 }, children: [new TextRun({ text: "Agri Predictive Analytics Model", font: "Cambria", size: 60, bold: true, color: GREEN })] }),
  new Paragraph({ spacing: { after: 360 }, children: [new TextRun({ text: "Forecasting district-level crop yield at week 20, and explaining the drivers to business users", size: 30, color: INK })] }),
  p([b("Project report"), new TextRun(" - Yuva Intern, Junior Data Scientist Internship in Nagpur")]),
  p([b("Author: "), new TextRun("Kalla Kushwanth")]),
  p([b("Period: "), new TextRun("22 Oct 2026 - 26 Nov 2026")]),
  gap(),
  new Paragraph({ shading: { fill: TINT, type: ShadingType.CLEAR, color: "auto" }, spacing: { before: 120, after: 120, line: 276 }, indent: { left: 120, right: 120 },
    children: [b("Data note. "), new TextRun("The brief describes about 350,000 records but supplies no file. All results in this report come from a seeded synthetic dataset (src/generate_data.py) built to contain every data problem the brief lists. The results therefore demonstrate the method; they are not real Vidarbha yield statistics.")] }),
  new Paragraph({ children: [new PageBreak()] }),

  // ------------------------------------------------ 1 summary
  h1("1. Summary"),
  p(`A fictional Nagpur agritech start-up wants to predict district-level crop yield early enough to act on procurement. I built a forecast issued at the end of week 20 of the agricultural year (about mid-October), using only weeks 1-20 of the current season plus earlier seasons. The model is a tuned gradient-boosting regressor trained on ${m.split.train.toLocaleString()} block-crop seasons (2006-2019), selected on ${m.split.val.toLocaleString()} validation seasons (2020-2022), refit on both and scored once on ${m.split.test.toLocaleString()} test seasons (2023-2025).`),
  p([b("Headline results. "), new TextRun(`At the district x crop level the final model has a mean absolute error of ${n(F.test.MAE_district, 2)} q/ha on the test years, against ${n(F.test_base.MAE_district, 2)} q/ha for the baseline (the 3-year rolling mean). That is ${n(F.imp_test, 0)}% better on test and ${n(F.imp_val, 0)}% better on validation.`)]),
  table(["Success criterion from the brief", "Result", "Evidence"], [
    ["Beat the baseline by at least 15%", "Met", `${n(F.imp_val, 1)}% on validation, ${n(F.imp_test, 1)}% on test`],
    ["Test within 5% of validation", "Not met", `Test MAE is ${n(F.gap_test_vs_val_pct, 0)}% above validation; the baseline itself got ${n(100 * (F.test_base.MAE_district / F.val_base.MAE_district - 1), 0)}% worse`],
    ["Top five drivers make business sense", "Met, with a caveat", "Rainfall and price signals dominate; price features are signals, not causes (section 9)"],
  ], [3500, 1700, 4546]),
  gap(),
  p([b("What I would tell the business. "), new TextRun(`The forecast is reliable in normal seasons (about ${n(RD.mape_normal_test, 0)}% average block-level error) and noticeably weaker in unusually wet seasons (about ${n(RD.mape_wet_test, 0)}%), which doubled in frequency in the test years. Shortfall calls for kharif crops were reliable in the 2025 hindsight check; rabi crop shortfall calls in a very wet year were not.`)]),

  // ------------------------------------------------ 2 data
  h1("2. Problem and data"),
  p(`The data is one row per block x crop x week of the agricultural year (week 1 = 1 June): ${m.raw_rows.toLocaleString()} rows and ${m.raw_cols} columns covering 6 districts (Nagpur, Wardha, Amravati, Yavatmal, Chandrapur, Bhandara), 48 blocks, 6 crops (soybean, cotton, tur, rice, wheat, gram) and agricultural years 2003-2025. Columns cover weekly rainfall and maximum temperature, block-level soil tests, weekly mandi price, season yield, and a few post-harvest columns.`),
  p("Because no file was provided, the data was generated with a documented data-generating process: yield responds to monsoon rainfall in a curved way (too little and too much both hurt), dry spells in the flowering window, heat, soil quality, an irrigation share, a slow technology trend and previous-year prices, plus district-level shocks (pink bollworm in Yavatmal cotton, floods in Amravati). Then the problems the brief lists were injected. The generator is seeded so the dataset can be rebuilt exactly."),
  ...img("01_raw_audit.png", 600, "Figure 1. Raw data audit: missing rainfall by week, mixed price units, mixed yield units."),

  // ------------------------------------------------ 3 cleaning
  h1("3. Cleaning"),
  p("Each fix is detected from the data rather than hard-coded, and the affected rows are counted."),
  table(["Problem", "Rows affected", "How it was found and fixed"], [
    ["Exact duplicate rows", CL.duplicates_removed.toLocaleString(), "Dropped exact copies including the record ID"],
    ["Inconsistent labels (Soya bean, Paddy, NAGPUR)", `${CL.crop_labels_fixed.toLocaleString()} crop, ${CL.district_labels_fixed.toLocaleString()} district`, "Trimmed, lower-cased and mapped to one name"],
    ["Prices per kg mixed with per quintal", CL.price_per_kg_rows.toLocaleString(), "Ratio to the same crop's median price in the same week was about 0.01; multiplied by 100"],
    ["Yield in kg/acre or t/ha", CL.yield_unit_converted_rows.toLocaleString(), "Converted using the declared unit to q/ha"],
    ["Yield mislabelled as q/ha", CL.yield_mislabelled_rows.toLocaleString(), "Values more than 5 times the crop median were kg/acre; divided by 40.47"],
    ["Missing rainfall and -999 sentinels", CL.rain_missing_rows.toLocaleString(), "Filled from the same gauge under another crop, then from other blocks in the district that week"],
  ], [3100, 1900, 4746]),
  gap(),
  p("Missing rainfall deserves a note. Heavy-rain weeks are more likely to go missing, so the imputed monsoon cells averaged 78.8 mm per week against 58.4 mm for the observed cells. A global or seasonal average would have understated monsoon totals, which is why neighbouring blocks in the same week were used instead."),
  ...img("02_after_cleaning.png", 600, "Figure 2. After cleaning: one price unit and one yield unit."),

  // ------------------------------------------------ 4 EDA + leakage
  h1("4. Exploratory analysis and leakage check"),
  ...img("03_eda_overview.png", 560, "Figure 3. Trends, district differences and the curved rainfall response."),
  p("Three observations shaped the modelling. Yields rise slowly with technology. Bad years (2009, 2014-15, 2018) are shared across districts, so weather is the main driver. The rainfall response is an inverted U, so a straight-line term will under-use it."),
  h2("Leakage"),
  p("Before building features I tested which columns would not exist on the forecast date."),
  table(["Column", "Why suspicious", "Correlation with yield"], m.leak_table.map((r) => [r.column, r["why suspicious"], n(r["correlation with yield (or yield deviation)"], 3)]), [2800, 4546, 2400], { numeric: false }),
  gap(),
  p("All five were excluded. To show why this matters, I compared three setups with the same random forest."),
  table(["Setup", "MAE (log-ratio)"], m.leak_demo.map((r) => [r.setup, n(r["MAE (log-ratio)"], 4)]), [6746, 3000], { numeric: true }),
  gap(),
  p(`A randomly shuffled cross-validation looks ${n((1 - m.leak_demo[1]["MAE (log-ratio)"] / m.leak_demo[0]["MAE (log-ratio)"]) * 100, 0)}% better than the honest setup because it lets the model see other blocks from the same year, which share weather. Keeping the leaky columns looks ${n((1 - m.leak_demo[2]["MAE (log-ratio)"] / m.leak_demo[0]["MAE (log-ratio)"]) * 100, 0)}% better. Neither is achievable on the forecast date.`),

  // ------------------------------------------------ 5 features
  h1("5. Feature engineering and splits"),
  p(`The final model uses ${m.n_features} features, of which ${m.n_engineered} are lag, rolling or ratio features. They come from five families, all computed from weeks 1-20 or earlier seasons:`),
  bullet([b("Rainfall: "), new TextRun("window sums, ratio to the block's own history (expanding, past only), 3-year rolling mean, longest dry spell in weeks 5-14, and the share of readings that were missing.")]),
  bullet([b("Temperature: "), new TextRun("mean temperature and the number of hot weeks in the flowering window.")]),
  bullet([b("Soil: "), new TextRun("the last available test (forward-filled, so never from the future), a missing flag and the N:P ratio.")]),
  bullet([b("Price: "), new TextRun("early-season level, volatility, momentum, and ratios to the previous year's early price and previous harvest price.")]),
  bullet([b("History: "), new TextRun("last year's yield, two years ago, 3-year rolling mean and standard deviation, ratios to the rolling mean, and a district-level lag.")]),
  p([b("High-cardinality categories. "), new TextRun("There are 48 blocks, 48 mandis and 240 seed varieties. Mandi is a one-to-one duplicate of block, so it was dropped. Block and variety use a smoothed target encoding that only looks at earlier years, so the encoding never sees the row's own year or the future. Crop and district (6 levels each) are one-hot encoded.")]),
  p([b("Missing values. "), new TextRun("Rainfall was imputed from neighbours as described in section 3. Soil tests were forward-filled from the block's previous test. Lag features are empty in the first seasons, so modelling starts in 2006. Tree models handle any remaining gaps natively.")]),
  p([b("Time-aware split. "), new TextRun("Train 2006-2019, validation 2020-2022, test 2023-2025. Cross-validation uses expanding windows (train up to 2013, 2015 and 2017; validate on the next two years). The target is log(yield / 3-year block-crop rolling mean), converted back to q/ha.")]),

  // ------------------------------------------------ 6 models
  h1("6. Models and tuning"),
  p("The baseline is the 3-year block-crop rolling mean, what an analyst would do without a model. I compared a ridge regression, a random forest and gradient boosting using the expanding-window cross-validation, then tuned gradient boosting with a 24-draw randomised search over the same folds."),
  table(["Model", "CV MAE (log-ratio)"], Object.entries(m.cv_table).sort((a, c) => a[1] - c[1]).map(([k, v]) => [k, n(v, 4)]), [6746, 3000], { numeric: true }),
  gap(),
  p("Tuning improved cross-validation error only slightly (0.1194 to 0.1193) but did reduce validation district error from 0.896 to 0.849 q/ha. I treat that gain as modest rather than decisive. The selected parameters are in the model card."),
  table(["Model on validation years", "MAE district (q/ha)", "WAPE %", "vs baseline"], vt.map((r) => [r.model, n(r.MAE_district, 3), n(r["WAPE_district_%"], 2), `${n(r["improvement_vs_baseline_%"], 1)}%`]), [4046, 2000, 1700, 2000], { numeric: true }),
  gap(),
  ...img("04_model_comparison.png", 600, "Figure 4. Model comparison on the validation years."),
  p("The linear model is worse than the baseline because yield reacts to rainfall in a curve and differently by crop; gradient boosting captures this without hand-built interactions."),

  // ------------------------------------------------ 7 metrics
  h1("7. Metrics that match the cost of errors"),
  p("Over-forecasting yield makes the start-up under-book supply; under-forecasting leaves it over-committed on storage and cash. Both costs scale with the size of the miss in quintals, so the primary metric is mean absolute error in q/ha at the district x crop x year level, the level the product is used at. I also report WAPE, and the recall of shortfall events at a fixed precision, because a missed shortfall is the costly error (a shortfall is a yield below 92% of the district-crop 3-year normal)."),
  table(["Metric", "Validation", "Test"], [
    ["MAE, district x crop (q/ha)", n(F.val.MAE_district, 3), n(F.test.MAE_district, 3)],
    ["MAE, block (q/ha)", n(F.val.MAE_block, 3), n(F.test.MAE_block, 3)],
    ["WAPE, district (%)", n(F.val["WAPE_district_%"], 2), n(F.test["WAPE_district_%"], 2)],
    ["Baseline MAE, district (q/ha)", n(F.val_base.MAE_district, 3), n(F.test_base.MAE_district, 3)],
    ["Improvement vs baseline (%)", n(F.imp_val, 1), n(F.imp_test, 1)],
    ["Shortfall recall at precision (threshold fixed on validation)", `${n(m.shortfall.val_recall * 100, 0)}% at ${n(m.shortfall.val_precision * 100, 0)}%`, `${n(m.shortfall.test_recall * 100, 0)}% at ${n(m.shortfall.test_precision * 100, 0)}%`],
  ], [5246, 2250, 2250], { numeric: true }),
  gap(),
  p(`The precision target of 70% was met on validation but not on test (${n(m.shortfall.test_precision * 100, 0)}%): on the test years the same threshold flags more false alarms while catching more real shortfalls.`),
  ...img("05_test_performance.png", 600, "Figure 5. Test years: predicted vs actual and the error distribution."),

  h2("Why test error is higher than validation"),
  p(`Test error is ${n(F.gap_test_vs_val_pct, 0)}% above validation, so the stability criterion is not met. The baseline also got worse (${n(100 * (F.test_base.MAE_district / F.val_base.MAE_district - 1), 0)}%), so the test years are harder, but the model degraded more than that. I looked for the cause rather than tuning against the test set.`),
  p(`The natural suspect is rainfall relative to the block's own history, because wet seasons are rare in training. Seasons more than 1.4 times the block's norm doubled from ${n(RD.wet_share_val * 100, 0)}% of validation rows to ${n(RD.wet_share_test * 100, 0)}% of test rows. In normal seasons the model is stable (average block-level error ${n(RD.mape_normal_val, 1)}% on validation and ${n(RD.mape_normal_test, 1)}% on test). In unusually wet seasons it reaches ${n(RD.mape_wet_test, 1)}%, with a bias of ${n(RD.bias_wet_test, 1)}%, meaning it forecasts a bigger collapse than actually happened. The effect is strongest in irrigated Bhandara (${n(RD.bhandara_wet_mape, 0)}% error, ${n(RD.bhandara_wet_bias, 0)}% bias) and for rabi crops (${n(RD.rabi_wet_bias, 0)}% bias), which are far less rain-sensitive than kharif crops. With few wet-season examples in training, the model transfers the kharif collapse pattern too widely.`),
  p([b("A follow-up experiment. "), new TextRun(`I tested a hybrid model (a linear stage with crop x rainfall interactions, then boosting on the residuals). It was worse on validation (${n(m.hybrid_exp[1]["validation MAE_district"], 3)} vs ${n(m.hybrid_exp[0]["validation MAE_district"], 3)} q/ha), so I kept plain gradient boosting. On the test years it looked better (${n(m.hybrid_exp[1]["test MAE_district (diagnostic only)"], 3)} vs ${n(m.hybrid_exp[0]["test MAE_district (diagnostic only)"], 3)}). I had already looked at test results by then, so I did not use that to select the model; it is a lead for a version 2 that needs a fresh hold-out.`)]),

  // ------------------------------------------------ 8 explainability
  h1("8. Explainability"),
  p(`Explanations use Shapley values. The shap package could not be installed in my offline environment, so the notebook uses a permutation-sampling Shapley estimator (${m.shap_method}); the same code uses shap.TreeExplainer automatically when the package is available.`),
  ...img("06_shap_summary.png", 620, "Figure 6. Mean absolute Shapley value and direction of effect for the top features."),
  table(["Feature family", "Share of attribution (%)"], Object.entries(m.family_share).map(([k, v]) => [k, n(v, 1)]), [6746, 3000], { numeric: true }),
  gap(),
  ...img("07_pdp.png", 560, "Figure 7. Partial dependence of the top numeric drivers."),

  h1("9. Do the drivers make business sense?"),
  bullet([b("Rainfall dominates. "), new TextRun("Monsoon rainfall in weeks 1-17 is the largest single driver, and its 3-year average (soil-moisture memory) is third. The partial-dependence curves are not straight lines: yields fall when the monsoon is far from what the block normally gets. An agronomist would expect this.")]),
  bullet([b("Price signals are the second family. "), new TextRun("The ratio of the early price to last harvest's price carries information about local supply, and good prices push farmers to invest more in inputs. The caveat is that these are market signals, not agronomic causes, and they are only available if mandi prices arrive on time for weeks 1-20. Part of their power comes from traders pricing in crop condition.")]),
  bullet([b("Yield history "), new TextRun("(last year relative to the 3-year norm, block effect, seed variety) adds a smaller, real share.")]),
  bullet([b("Dry-spell length, soil and heat rank lower than I expected "), new TextRun("from the exploratory analysis. They help, but rainfall totals and history carry most of the predictable signal.")]),
  bullet([b("Tur "), new TextRun("appears in the top five because it is the crop most hurt by wet monsoons in this data; that is crop identity acting through rainfall, not an independent cause.")]),

  // ------------------------------------------------ 10 actions
  h1("10. From forecast to action"),
  p("To show how the forecast would be used, I trained on seasons up to 2024 and forecast the 2025 season at week 20. For each district x crop I compared predicted supply with the 3-year normal, and added early-season price momentum into a priority score (shortfall plus half of price momentum; a heuristic, not an optimiser). Rules: book early when predicted supply is 4% or more below normal, wait and buy spot when 4% or more above, otherwise follow the routine plan."),
  ...img("08_procurement_heatmap.png", 480, "Figure 8. Expected 2025 supply versus the 3-year normal (%), forecast at week 20."),
  table(["District", "Crop", "Predicted supply vs normal (%)", "Actual (%)", "Action"], m.actions_top.map((r) => [r.district, r.crop, n(r["supply_vs_normal_%"], 1), n(r["actual_supply_vs_normal_%"], 1), r.action.split(":")[0]]), [1700, 1300, 2700, 1700, 2346], { numeric: false }),
  gap(),
  p(`Counts across all 36 district-crop pairs: ${Object.entries(m.actions_counts).map(([k, v]) => `${k.split(":")[0].toLowerCase()} ${v}`).join(", ")}. A hindsight check against the 2025 actuals gives a rank correlation of ${n(m.hindsight.rho, 2)} and the right direction (shortfall vs surplus) in ${n(m.hindsight.direction_hit * 100, 0)}% of pairs.`),
  p("The hindsight check is informative about where to trust the forecast. Bhandara's kharif shortfalls were real (tur forecast \u221258%, actual \u221256%; soybean forecast \u221254%, actual \u221244%). Its rabi flags were wrong (gram forecast \u221231%, actual +10%; rice forecast \u221214%, actual +3%), which is the wet-season weakness from section 7. In practice I would treat rabi shortfall flags in unusually wet years as low confidence."),

  // ------------------------------------------------ 11 fairness
  h1("11. Stretch: fairness and stability"),
  p("I checked error and signed bias (negative means the model forecast less than actual) on the test years by district, by crop, and by farm size (terciles of sown area, as a proxy for customer groups)."),
  table(["District", "MAE (q/ha)", "MAPE (%)", "Bias (%)"], fairD.map((r) => [r.district, n(r.MAE_qha, 2), n(r.MAPE_pct, 1), n(r.bias_pct, 1)]), [3500, 2000, 2000, 2246], { numeric: true }),
  gap(),
  table(["Farm size group", "MAE (q/ha)", "MAPE (%)", "Bias (%)"], fairS.map((r) => [r.size_group, n(r.MAE_qha, 2), n(r.MAPE_pct, 1), n(r.bias_pct, 1)]), [3500, 2000, 2000, 2246], { numeric: true }),
  gap(),
  p("Error is similar across small, medium and large farms. The weak spot is region and weather regime: Bhandara has the highest error and the largest under-forecast bias. Among crops, wheat has the largest absolute error in q/ha because its yields are largest, and gram has the largest under-forecast bias."),
  ...img("09_fairness_by_district.png", 600, "Figure 9. Test bias and MAE by district."),
  p([b("Distribution shift. "), new TextRun(`The population stability index between training and test is above 0.25 (a major shift) for the price ratio to last year (${n(m.psi.price_ratio_prev, 2)}) and for monsoon rainfall (${n(m.psi.rain_mon, 2)}), and moderate for soil organic carbon (${n(m.psi.soil_oc, 2)}). These are the features to monitor in production.`)]),
  p([b("Recalibration. "), new TextRun(`I tested an online correction that adds half of the previous season's district-crop residual. It made forecasts worse on 2024-25 (district MAE ${n(m.recal.raw, 2)} to ${n(m.recal.cal, 2)} q/ha; Chandrapur ${n(m.recal.chd_raw, 2)} to ${n(m.recal.chd_cal, 2)}), because one season's residual is mostly weather noise shared across blocks. Annual retraining already absorbs the Chandrapur drift built into the data (Chandrapur test bias is small). I would not ship this recalibration; a multi-season, significance-tested correction or a wider uncertainty band in unusually wet years are better options.`)]),

  // ------------------------------------------------ 12 wrong prediction
  h1("12. One wrong prediction, explained"),
  p(`The largest percentage error on the test years is ${W.block} (${W.district}), ${W.crop.toLowerCase()}, ${W.year}: the model forecast ${n(W.pred, 1)} q/ha and the actual yield was ${n(W.actual, 1)} q/ha, an over-forecast of ${n(W.pct, 0)}%.`),
  bullet([b("What the model saw. "), new TextRun(`The 3-year baseline was ${n(W.normal, 1)} q/ha, and the model forecast ${n(W.model_ratio, 2)} times the baseline. The two largest contributions were both upward and both from price features (last harvest's price relative to now, and early price momentum). The rainfall features contributed almost nothing (each under 0.01 in log units, apart from the 3-year rain average at -0.03).`)]),
  bullet([b("What actually happened. "), new TextRun(`The monsoon (weeks 1-17) was ${n(W.rain, 0)} mm, ${n(W.rel_wet, 2)} times the block's own history and wetter than ${n(W.rain_pct, 0)}% of its earlier seasons. In 2006-2022, ${W.analog_n} soybean seasons with similar relative wetness realised on average ${n(W.analog_ratio, 2)} times their baseline. This one realised ${n(W.actual_ratio, 2)} times. The data already contained the pattern; the model did not apply it.`)]),
  bullet([b("A second contributor. "), new TextRun(`The baseline itself was inflated: the block's last three yields were ${W.last3.map((v) => n(v, 1)).join(", ")} q/ha, and the very good 2021 season lifted the average to ${n(W.normal, 1)}.`)]),
  bullet([b("Ruled out. "), new TextRun(`Late-season weather: rainfall in weeks 21-40 (${n(W.late_rain, 0)} mm vs a past mean of ${n(W.late_rain_hist, 0)} mm) and hot weeks in the grain-filling window (${W.heat_late}) were normal, so this was not an unobservable late shock.`)]),
  bullet([b("Lesson. "), new TextRun("This is a model miss, not noise. Price features outweighed rainfall in an unusually wet season. Fixes to test next: crop-specific wet-season features, monotonic constraints on rainfall, or the hybrid model from section 7, each judged on a fresh hold-out.")]),
  ...img("10_wrong_prediction.png", 600, "Figure 10. Shapley contributions for this forecast and the block's monsoon rainfall history."),

  // ------------------------------------------------ 13 limits
  h1("13. Limitations and next steps"),
  bullet([b("Simulated data. "), new TextRun("All numbers describe a synthetic dataset. The workflow transfers to real data, the figures do not.")]),
  bullet([b("Stability criterion not met. "), new TextRun("Test error was higher than validation, largely in unusually wet seasons; see section 7.")]),
  bullet([b("Test set looked at once during development. "), new TextRun("After the first full run I inspected test errors to diagnose the gap. I did not change the selected model because of it; the hybrid experiment is labelled as a diagnostic.")]),
  bullet([b("Shapley estimator. "), new TextRun("Used instead of the shap package for offline reproducibility; estimates are Monte-Carlo and slightly noisy.")]),
  bullet([b("Price features depend on timely mandi data "), new TextRun("and partly encode traders' expectations.")]),
  bullet([b("Next steps. "), new TextRun("Add wet-season handling and test the hybrid on a fresh hold-out; quantile forecasts so the business sees a range; monitor the shifted features; validate on real district data.")]),

  h1("Appendix: reproducibility"),
  p("Repository layout: src/generate_data.py (synthetic data), notebooks/analysis.py and notebooks/agri_yield_analysis.ipynb (full analysis with outputs), src/build_notebook.py (executes the notebook), models/yield_model.joblib, reports/model_card.md, reports/metrics.json, reports/test_predictions.csv and reports/figures. To rebuild: run python src/generate_data.py, then python src/build_notebook.py. All random seeds are fixed (2026 for the data, 42 for modelling)."),
];

const doc = new Document({
  creator: "Kalla Kushwanth", title: "Agri Predictive Analytics Model - Project report",
  styles: {
    default: { document: { run: { font: "Calibri", size: 22, color: INK } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: "Cambria", size: 32, bold: true, color: GREEN }, paragraph: { spacing: { before: 320, after: 140 }, keepNext: true, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: "Cambria", size: 26, bold: true, color: GREEN }, paragraph: { spacing: { before: 220, after: 100 }, keepNext: true, outlineLevel: 1 } },
    ],
  },
  numbering: { config: [{ reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] }] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1080, bottom: 1080, left: 1080, right: 1080 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Agri Predictive Analytics Model - page ", size: 18, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], size: 18, color: GREY })] })] }) },
    children: body,
  }],
});

Packer.toBuffer(doc).then((buf) => {
  const out = path.join(ROOT, "deliverables/Project_Report.docx");
  fs.writeFileSync(out, buf);
  console.log("wrote", out, (buf.length / 1e6).toFixed(1), "MB");
});
