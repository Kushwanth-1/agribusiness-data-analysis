# Model card: Agri yield forecaster (week-20)

## Model details
- **Task:** forecast season yield (q/ha) for a block x crop at the end of week 20 of the agricultural year (about mid-October); reported at district x crop level.
- **Model:** HistGradientBoostingRegressor (scikit-learn) on target log(yield / 3-year block-crop rolling mean); prediction = rolling mean x exp(output).
- **Tuned parameters:** {"min_samples_leaf": 20, "max_leaf_nodes": 31, "max_iter": 350, "max_features": 0.7, "max_depth": 4, "learning_rate": 0.08, "l2_regularization": 1.0}
- **Trained on:** seasons 2006-2022 (selected on 2020-2022 validation, refit on train+validation). File: `models/yield_model.joblib` (dict with `model`, `features`, `cutoff_week`).
- **Features:** 50 (rainfall, temperature, soil, price signals, yield history, past-only target encodings, crop and district one-hot). See notebook section 5.

## Intended use
Early procurement planning (which district-crop pairs to book early, wait on, or buy routinely). Not intended for insurance, credit decisions about individual farmers, or any use that needs farm-level accuracy.

## Data
Seeded **synthetic** dataset (`src/generate_data.py`), 349,959 raw weekly rows, 6 districts, 48 blocks, 6 crops, 2003-2025, built to contain the data problems in the brief. **No real farm data was used.** Results demonstrate the method only.

## Evaluation (district x crop x year level)
| | Validation 2020-22 | Test 2023-25 |
|---|---|---|
| Model MAE (q/ha) | 0.849 | 1.187 |
| Baseline MAE (3-year rolling mean) | 1.465 | 1.721 |
| Improvement vs baseline | 42.0% | 31.0% |
| WAPE | 5.03% | 7.20% |
| Shortfall recall at precision | 61% at 73% | 82% at 61% |

**Success criteria:** beating the baseline by 15% is met. Test within 5% of validation is **not met** (test MAE 40% above validation).

## Known weaknesses
- **Unusually wet seasons** (rainfall above 1.4x the block's own history): average error 15.9% vs 9.6% in normal seasons, bias -8.6% (the model forecasts too large a collapse). Worst in irrigated Bhandara and for rabi crops. These seasons doubled in frequency in the test years.
- **Price features** (second most important family) are market signals and need timely mandi data for weeks 1-20.
- **Shift:** the price ratio to last year and monsoon rainfall have PSI above 0.25 between train and test; monitor them.
- **Simple recalibration** (adding half of last season's district-crop residual) made forecasts worse and is not used.
- Farm-size groups show similar error; district and weather regime are the fairness-relevant axes here.

## Explainability
Shapley values (permutation-sampling estimator; `shap.TreeExplainer` is used automatically if installed) and partial-dependence plots. Attribution shares: Rainfall 27.8%, Price signals 25.6%, Yield history / block & variety effect 19.5%, Crop / district identity 10.0%, Soil 7.4%, Temperature 6.5%, Other (area, trend) 3.2%.

## Ethical and practical notes
Forecasts are decision support for a buyer, so errors affect farmers indirectly through procurement timing and prices. Do not use rabi shortfall flags in unusually wet years without human review. Retrain annually and re-check bias by district.
